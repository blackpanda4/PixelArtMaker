// Select purple input
// Select size input

//  call makeGrid , when size submitted by the user()

function makeGrid(event) {

    // preventing and reloading the page to stop the submit action

    event.preventDefault();
    // make the needed variables

    var height = document.getElementById("inputHeight").value;
    var width = document.getElementById("inputWidth").value;
    tableCanvas = document.getElementById("pixelCanvas");

    //removing the table first
    tableCanvas.innerHTML = "";

    // Making some rows and cellshapes
    for (var N = 0; N < height; N++) {
        var tableRow = document.createElement("tr");
        for (var B = 0; B < width; B++) {
            var cellshape = document.createElement("td");
            cellshape.addEventListener("click", function () {
                var purple = document.getElementById("colorPicker").value;
                this.style.backgroundColor = purple;
            });
         tableRow.appendChild(cellshape);
        }
        tableCanvas.appendChild(tableRow)
    }
}